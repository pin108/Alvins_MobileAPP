package com.example.py7.appbiodata

import android.Manifest
import android.annotation.TargetApi
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import com.blogspot.atifsoftwares.circularimageview.CircularImageView
import com.theartofdev.edmodo.cropper.CropImage
import com.theartofdev.edmodo.cropper.CropImageView
import java.text.SimpleDateFormat
import java.util.*

class EditActivity : AppCompatActivity() {
    var helper: DBHelper? = null
    var TxNomor: EditText? = null
    var TxNama: EditText? = null
    var TxTempatLahir: EditText? = null
    var TxTanggal: EditText? = null
    var TxAlamat: EditText? = null
    var SpJK: Spinner? = null
    var id: Long = 0
    var datePickerDialog: DatePickerDialog? = null
    var dateFormatter: SimpleDateFormat? = null
    var imageView: CircularImageView? = null
    var uri: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)
        helper = DBHelper(this)
        id = intent.getLongExtra(DBHelper.row_id, 0)
        TxNomor = findViewById<View>(R.id.txNomor_Edit) as EditText
        TxNama = findViewById<View>(R.id.txNama_Edit) as EditText
        TxTempatLahir = findViewById<View>(R.id.txTempatLahir_Edit) as EditText
        TxTanggal = findViewById<View>(R.id.txTglLahir_Edit) as EditText
        TxAlamat = findViewById<View>(R.id.txAlamat_Edit) as EditText
        SpJK = findViewById<View>(R.id.spJK_Edit) as Spinner
        imageView = findViewById<View>(R.id.image_profile) as CircularImageView
        dateFormatter = SimpleDateFormat("dd-MM-yyyy", Locale.US)
        TxTanggal!!.setOnClickListener { showDateDialog() }
        imageView!!.setOnClickListener { CropImage.startPickImageActivity(this@EditActivity) }
        data
    }

    private fun showDateDialog() {
        val calendar = Calendar.getInstance()
        datePickerDialog = DatePickerDialog(
            this,
            { view, year, month, dayOfMonth ->
                val newDate = Calendar.getInstance()
                newDate[year, month] = dayOfMonth
                TxTanggal!!.setText(dateFormatter!!.format(newDate.time))
            }, calendar[Calendar.YEAR], calendar[Calendar.MONTH],
            calendar[Calendar.DAY_OF_MONTH]
        )
        datePickerDialog!!.show()
    }

    private val data: Unit
        private get() {
            val cursor = helper!!.oneData(id)
            if (cursor.moveToFirst()) {
                val nomor = cursor.getString(cursor.getColumnIndex(DBHelper.row_nomor))
                val nama = cursor.getString(cursor.getColumnIndex(DBHelper.row_nama))
                val tempatLahir = cursor.getString(cursor.getColumnIndex(DBHelper.row_tempatLahir))
                val jk = cursor.getString(cursor.getColumnIndex(DBHelper.row_jk))
                val tanggal = cursor.getString(cursor.getColumnIndex(DBHelper.row_tglLahir))
                val alamat = cursor.getString(cursor.getColumnIndex(DBHelper.row_alamat))
                val foto = cursor.getString(cursor.getColumnIndex(DBHelper.row_foto))
                TxNomor!!.setText(nomor)
                TxNama!!.setText(nama)
                if (jk == "Laki-Laki") {
                    SpJK!!.setSelection(0)
                } else if (jk == "Perempuan") {
                    SpJK!!.setSelection(1)
                }
                TxTempatLahir!!.setText(tempatLahir)
                TxTanggal!!.setText(tanggal)
                TxAlamat!!.setText(alamat)
                if (foto == "null") {
                    imageView!!.setImageResource(R.drawable.ic_person_black_24dp)
                } else {
                    imageView!!.setImageURI(Uri.parse(foto))
                }
            }
        }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.edit_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.save_edit -> {
                val nomor: String = TxNomor!!.text.toString()
                val nama: String = TxNama!!.text.toString()
                val tempatLahir: String = TxTempatLahir!!.text.toString()
                val tanggal: String = TxTanggal!!.text.toString()
                val alamat: String = TxAlamat!!.text.toString()
                val jk: String = SpJK!!.selectedItem.toString()
                val values = ContentValues()
                values.put(DBHelper.row_nomor, nomor)
                values.put(DBHelper.row_nama, nama)
                values.put(DBHelper.row_tempatLahir, tempatLahir)
                values.put(DBHelper.row_tglLahir, tanggal)
                values.put(DBHelper.row_alamat, alamat)
                values.put(DBHelper.row_jk, jk)
                values.put(DBHelper.row_foto, uri.toString())
                if (nomor == "" || nama == "" || tempatLahir == "" || tanggal == "" || alamat == "") {
                    Toast.makeText(this@EditActivity, "Data Tidak Boleh Kosong", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    helper!!.updateData(values, id)
                    Toast.makeText(this@EditActivity, "Data Tersimpan", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
        when (item.itemId) {
            R.id.delete_edit -> {
                val builder = AlertDialog.Builder(this@EditActivity)
                builder.setMessage("Data ini akan dihapus.")
                builder.setCancelable(true)
                builder.setPositiveButton(
                    "Hapus"
                ) { dialog, which ->
                    helper!!.deleteData(id)
                    Toast.makeText(this@EditActivity, "Data Terhapus", Toast.LENGTH_SHORT).show()
                    finish()
                }
                builder.setNegativeButton(
                    "Cancel"
                ) { dialog, which -> dialog.cancel() }
                val alertDialog = builder.create()
                alertDialog.show()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    @TargetApi(Build.VERSION_CODES.M)
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == CropImage.PICK_IMAGE_CHOOSER_REQUEST_CODE
            && resultCode == RESULT_OK
        ) {
            val imageuri = CropImage.getPickImageResultUri(this, data)
            if (CropImage.isReadExternalStoragePermissionsRequired(this, imageuri)) {
                uri = imageuri
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 0)
            } else {
                startCrop(imageuri)
            }
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.getActivityResult(data)
            if (resultCode == RESULT_OK) {
                imageView!!.setImageURI(result.uri)
                uri = result.uri
            }
        }
    }

    private fun startCrop(imageuri: Uri) {
        CropImage.activity(imageuri)
            .setGuidelines(CropImageView.Guidelines.ON)
            .setAspectRatio(1, 1)
            .start(this)
        uri = imageuri
    }
}