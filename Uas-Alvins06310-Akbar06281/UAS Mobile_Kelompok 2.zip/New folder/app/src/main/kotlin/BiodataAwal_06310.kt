package com.example.py7.appbiodata

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity(), OnItemClickListener {
    var listView: ListView? = null
    var helper: DBHelper? = null
    var inflater: LayoutInflater? = null
    var dialogView: View? = null
    var Tv_Nomor: TextView? = null
    var Tv_Nama: TextView? = null
    var Tv_TempatLahir: TextView? = null
    var Tv_JK: TextView? = null
    var Tv_Tanggal: TextView? = null
    var Tv_Alamat: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        val fab = findViewById<View>(R.id.fab) as FloatingActionButton
        fab.setOnClickListener {
            startActivity(
                Intent(
                    this@MainActivity,
                    AddActivity::class
                )
            )
        }
        helper = DBHelper(this)
        listView = findViewById<View>(R.id.list_data) as ListView
        listView!!.onItemClickListener = this
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId
        return if (id == R.id.action_settings) {
            true
        } else super.onOptionsItemSelected(item)
    }

    fun setListView() {
        val cursor = helper!!.allData()
        val customCursorAdapter = CustomCursorAdapter(this, cursor, 1)
        listView!!.adapter = customCursorAdapter
    }

    override fun onItemClick(parent: AdapterView<*>?, view: View, i: Int, x: Long) {
        val getId = view.findViewById<View>(R.id.listID) as TextView
        val id: Long = getId.text.toString()
        val cur = helper!!.oneData(id)
        cur.moveToFirst()
        val builder = AlertDialog.Builder(this@MainActivity)
        builder.setTitle("Pilih Opsi")

        //Add a list
        val options = arrayOf("Lihat Data", "Edit Data", "Hapus Data")
        builder.setItems(options) { dialog, which ->
            when (which) {
                0 -> {
                    val viewData = AlertDialog.Builder(this@MainActivity)
                    inflater = layoutInflater
                    dialogView = inflater.inflate(R.layout.view_data, null)
                    viewData.setView(dialogView)
                    viewData.setTitle("Lihat Data")
                    Tv_Nomor = dialogView.findViewById<View>(R.id.tv_No) as TextView
                    Tv_Nama = dialogView.findViewById<View>(R.id.tv_Nama) as TextView
                    Tv_TempatLahir =
                        dialogView.findViewById<View>(R.id.tv_TempatLahir) as TextView
                    Tv_Tanggal =
                        dialogView.findViewById<View>(R.id.tv_Tanggal) as TextView
                    Tv_JK = dialogView.findViewById<View>(R.id.tv_JK) as TextView
                    Tv_Alamat =
                        dialogView.findViewById<View>(R.id.tv_Alamat) as TextView
                    Tv_Nomor!!.text =
                        "NIM: " + cur.getString(cur.getColumnIndex(DBHelper.row_nomor))
                    Tv_Nama!!.text =
                        "Nama: " + cur.getString(cur.getColumnIndex(DBHelper.row_nama))
                    Tv_TempatLahir!!.text =
                        "IPK: " + cur.getString(cur.getColumnIndex(DBHelper.row_tempatLahir))
                    Tv_JK!!.text =
                        "Jenis Kelamin: " + cur.getString(cur.getColumnIndex(DBHelper.row_jk))
                    Tv_Tanggal!!.text =
                        "Tanggal Lahir: " + cur.getString(cur.getColumnIndex(DBHelper.row_tglLahir))
                    Tv_Alamat!!.text =
                        "Mata Kuliah: " + cur.getString(cur.getColumnIndex(DBHelper.row_alamat))
                    viewData.setPositiveButton(
                        "OK"
                    ) { dialog, which -> dialog.dismiss() }
                    viewData.show()
                }
            }
            when (which) {
                1 -> {
                    val iddata = Intent(
                        this@MainActivity,
                        EditActivity::class
                    )
                    iddata.putExtra(DBHelper.row_id, id)
                    startActivity(iddata)
                }
            }
            when (which) {
                2 -> {
                    val builder1 = AlertDialog.Builder(this@MainActivity)
                    builder1.setMessage("Data ini akan dihapus.")
                    builder1.setCancelable(true)
                    builder1.setPositiveButton(
                        "Hapus"
                    ) { dialog, which ->
                        helper!!.deleteData(id)
                        Toast.makeText(this@MainActivity, "Data Terhapus", Toast.LENGTH_SHORT)
                            .show()
                        setListView()
                    }
                    builder1.setNegativeButton(
                        "Batal"
                    ) { dialog, which -> dialog.cancel() }
                    val alertDialog = builder1.create()
                    alertDialog.show()
                }
            }
        }
        val dialog = builder.create()
        dialog.show()
    }

    override fun onResume() {
        super.onResume()
        setListView()
    }
}