package com.example.py7.appbiodata

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context?) :
    SQLiteOpenHelper(context, database_name, null, 2) {
    private val db: SQLiteDatabase
    override fun onCreate(db: SQLiteDatabase) {
        val query =
            ("CREATE TABLE " + table_name + "(" + row_id + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + row_nomor + " TEXT, " + row_nama + " TEXT, " + row_jk + " TEXT, "
                    + row_tempatLahir + " TEXT, " + row_tglLahir + " TEXT, " + row_alamat + " TEXT, " + row_foto + " TEXT)")
        db.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase, i: Int, x: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + table_name)
    }

    //Get All SQLite Data
    fun allData(): Cursor {
        return db.rawQuery("SELECT * FROM $table_name", null)
    }

    //Get 1 Data By ID
    fun oneData(id: Long): Cursor {
        return db.rawQuery("SELECT * FROM $table_name WHERE $row_id=$id", null)
    }

    //Insert Data to Database
    fun insertData(values: ContentValues?) {
        db.insert(table_name, null, values)
    }

    //Update Data
    fun updateData(values: ContentValues?, id: Long) {
        db.update(table_name, values, row_id + "=" + id, null)
    }

    //Delete Data
    fun deleteData(id: Long) {
        db.delete(table_name, row_id + "=" + id, null)
    }

    companion object {
        const val database_name = "db_biodata"
        const val table_name = "tabel_biodata"
        const val row_id = "_id"
        const val row_nomor = "Nomor"
        const val row_nama = "Nama"
        const val row_jk = "JK"
        const val row_tempatLahir = "TempatLahir"
        const val row_tglLahir = "Tanggal"
        const val row_alamat = "Alamat"
        const val row_foto = "Foto"
    }

    init {
        db = writableDatabase
    }
}